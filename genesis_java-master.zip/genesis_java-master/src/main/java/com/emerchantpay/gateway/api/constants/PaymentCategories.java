package com.emerchantpay.gateway.api.constants;

public class PaymentCategories {
    public static String PAYLATER = "pay_later";
    public static String PAYOVERTIME = "pay_over_time";

}
