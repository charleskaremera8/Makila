package com.emerchantpay.gateway.api.exceptions;

public class ServerException extends GenesisException {
	private static final long serialVersionUID = 1L;
}
