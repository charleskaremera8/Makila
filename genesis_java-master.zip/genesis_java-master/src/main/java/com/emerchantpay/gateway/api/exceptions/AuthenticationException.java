package com.emerchantpay.gateway.api.exceptions;

public class AuthenticationException extends GenesisException {
	private static final long serialVersionUID = 1L;
}
