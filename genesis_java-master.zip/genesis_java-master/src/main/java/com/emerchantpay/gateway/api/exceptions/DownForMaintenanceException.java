package com.emerchantpay.gateway.api.exceptions;

public class DownForMaintenanceException extends GenesisException {
	private static final long serialVersionUID = 1L;
}
