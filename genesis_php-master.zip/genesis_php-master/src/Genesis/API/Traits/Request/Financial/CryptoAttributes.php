<?php
/*
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @license     http://opensource.org/licenses/MIT The MIT License
 */

namespace Genesis\API\Traits\Request\Financial;

use Genesis\Utils\Common;

/**
 * Trait CryptoAttributes
 * @package Genesis\API\Traits\Request\Financial
 *
 * @method $this getCrypto() Signifies whether a purchase of crypto-currency transaction is performed
 */
trait CryptoAttributes
{
    /**
     * Signifies whether a purchase of crypto-currency transaction is performed
     *
     * Must be populated when purchasing crypto-currency with a VISA card and MCC is 6051.
     * Must be populated when purchasing crypto-currency with a MASTER or
     * INTL MAESTRO card and MCC is one of 6051, 6211.
     *
     * Contact tech-support@emerchantpay.com for more details
     *
     * @var bool $crypto
     */
    protected $crypto;

    /**
     * Signifies whether a purchase of crypto-currency transaction is performed
     *
     * @param bool $value
     * @return CryptoAttributes
     */
    public function setCrypto($value)
    {
        $this->crypto = Common::toBoolean($value);

        return $this;
    }
}
