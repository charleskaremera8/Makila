<?php

namespace spec\Genesis\API\Stubs\Traits\Request\Financial;

/**
 * Class PproAttributesStub
 *
 * Used to spec PproAttributes trait
 *
 * @package spec\Genesis\API\Traits\Request\Financial
 */
class PproAttributesStub
{
    use \Genesis\API\Traits\Request\Financial\PproAttributes;
}
