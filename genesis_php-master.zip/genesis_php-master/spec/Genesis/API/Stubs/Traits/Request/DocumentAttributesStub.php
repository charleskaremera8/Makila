<?php

namespace spec\Genesis\API\Stubs\Traits\Request;

/**
 * Class DocumentAttributesStub
 *
 * Used to spec DocumentAttributes trait
 *
 * @package spec\Genesis\API\Traits\Request
 */
class DocumentAttributesStub
{
    use \Genesis\API\Traits\Request\DocumentAttributes;
}
